import java.util.*;
import java.io.*;
import java.nio.file.Path;

public class max_min{

    static String path = "pmed";
    public static void main(String[] args)throws Exception{
        for(int i=1;i<=25;i++){
            describes(path+i+".in");
        }
        for(int i=26;i<=40;i++){
            describes2(path+i+".txt");
        }
        
        

    }

    static public void describes(String path)throws Exception{
        Scanner scanner = new Scanner( new File(path), "UTF-8" );
        String _text = scanner.useDelimiter("\\A").next();
        String[] text = _text.split("\\s+");
        System.out.print("file : "+path+" vertex : "+text[0]+" edges : "+text[1]+ " p : "+text[2]+" dimension : "+text[0]+"x"+text[0]);
        String[] obj = Arrays.copyOfRange(text, 3, text.length);

        int[] arr = new int[obj.length];
        for(int i=0;i<obj.length;i++){
            arr[i] = Integer.parseInt(obj[i]);
        }
        Arrays.sort(arr);
        System.out.print(" min : "+arr[0]+" max : "+arr[arr.length-1]+"\n");
        // for(int e : arr){
        //     System.out.println(e);
        // }
    }

    
    static public void describes2(String path)throws Exception{
        Scanner scanner = new Scanner( new File(path), "UTF-8" );
        String _text = scanner.useDelimiter("\\A").next();
        String[] text = _text.split("\\s+");
        System.out.print("file : "+path+" vertex : "+text[1]+" edges : "+text[2]+ " p : "+text[3]+" dimension : "+text[1]+"x"+text[1]);
        String[] obj = Arrays.copyOfRange(text, 4, text.length);

        int[] arr = new int[obj.length];
        for(int i=0;i<obj.length;i++){
            arr[i] = Integer.parseInt(obj[i]);
        }
        Arrays.sort(arr);
        System.out.print(" min : "+arr[0]+" max : "+arr[arr.length-1]+"\n");
        // for(int e : arr){
        //     System.out.println(e);
        // }
    }
    
}