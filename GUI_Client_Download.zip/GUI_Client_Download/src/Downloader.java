import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Paths;
import java.sql.SQLOutput;

public class Downloader {




    public String get_file_name(String url) {
        try{
            if(Paths.get(new URI(url).getPath()).getFileName().toString().equals(url))
                return "Can't Download this File from this url";
            else
                return Paths.get(new URI(url).getPath()).getFileName().toString();
        }
        catch (Exception e){
            return "Can't Download this File";
        }
    }

    public Boolean can_download(String url)throws IOException {
        URLConnection conn = null;
        try{
            URL _url = new URL(url);
            conn = _url.openConnection();
            return true;
        }
        catch (Exception e){
            return false;
        }
        finally {
            if(conn!=null)
            conn.getInputStream().close();
        }
    }

    public int get_file_size(String url) throws IOException{
        URLConnection conn = null;
        try{
            URL _url = new URL(url);
            conn = _url.openConnection();
            return conn.getContentLength();
        }
        catch (Exception e){
            return 0;
        }
        finally {
            if(conn!=null)
                conn.getInputStream().close();
        }
    }


    public ReadableByteChannel get_rbc(String _url)throws Exception{
        URL url = new URL(_url);
        return Channels.newChannel(url.openStream());
    }



    public static void main(String[] argv) throws Exception {
        String file_rec = "f:/code/OSClass/Receive/test.jpg";
        String _url = "https://scontent.fbkk8-1.fna.fbcdn.net/v/t1.0-9/118041569_3632909353412058_1156028098468255292_o.jpg?_nc_cat=1&_nc_sid=730e14&_nc_eui2=AeG09-a4RjGNdXnSOf_q3HwSv5VYrXNX0NW_lVitc1fQ1QbvNowIXVoKaZWfx1S-YB9XsapJ81q4jYRrQ37RU-Vq&_nc_ohc=x5bP0V97GJAAX-1FJCR&_nc_ht=scontent.fbkk8-1.fna&oh=dca29d98a305b72ee886715cab28a6d9&oe=5F627265";
        int size;
        int byteRead;
        InputStream is = null;
        int current = 0;
        FileOutputStream fos = null;

        URLConnection conn = null;
        ReadableByteChannel rbc= null;
        try{
            fos = new FileOutputStream(file_rec);
            URL url = new URL(_url);
            conn  = url.openConnection();
            rbc = Channels.newChannel(url.openStream());
            size = conn.getContentLength();
            long b_read;
            while (current<size){
                b_read = fos.getChannel().transferFrom(rbc,current,6000);
                current+=b_read;
                System.out.println(current);
            }
            System.out.println("success");
        }
        catch (Exception e){

        }
        finally {
            if(conn!=null)
                conn.getInputStream().close();
            if (fos != null)
                fos.close();


        }

    }
}
