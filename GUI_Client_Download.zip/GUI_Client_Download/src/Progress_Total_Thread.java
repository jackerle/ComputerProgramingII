import javax.swing.*;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Progress_Total_Thread extends Thread{

    private String path;
    private JProgressBar jProgressBart;
    private int size;
    private String f_name;
    private JLabel progress1;



    public void run(){
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;



        try{
            while(ThreadWatcher.count_dl<10){

                Thread.sleep(10);
            }
            fos = new FileOutputStream(path+"/"+f_name);
            bos = new BufferedOutputStream(fos);
            path+="/dump_0";
            ByteBuffer _bArr = ByteBuffer.allocate(size);
            for(int i=0;i<=9;i++){
                Path p = Paths.get(path+i);
                byte[] b = Files.readAllBytes(p);
                _bArr.put(b);
                new File(path+i).delete();
                int finalI = i;
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        jProgressBart.setValue(finalI +1);
                        progress1.setText(String.valueOf((finalI+1)/10*100)+"%");
                    }
                });


            }
            byte[] bArr = _bArr.array();
            System.out.println(bArr.length);
            bos.write(bArr,0,size);
            bos.flush();
            System.exit(0);
        }
        catch (Exception e){

        }
    }




    public Progress_Total_Thread(JProgressBar jProgressBart,String dir,int size,String f_name,JLabel jb){
        this.path = dir;
        this.size = size;
        this.jProgressBart = jProgressBart;
        this.f_name = f_name;
        this.progress1 = jb;
        jProgressBart.setMinimum(0);
        jProgressBart.setMaximum(10);
    }





}
