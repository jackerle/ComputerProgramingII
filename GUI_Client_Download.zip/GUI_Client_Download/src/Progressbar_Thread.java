import javax.swing.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.channels.ReadableByteChannel;

public class Progressbar_Thread extends Thread {

    private ReadableByteChannel rbc;
    private JProgressBar jProgressBar;
    private JLabel progress;
    private int offset;
    private int part_size;
    private int percent = 0;
    private String _url;
    private  String dir;

    public void run(){
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        InputStream is = null;
        long current = offset*part_size;
        String path = this.dir+"/dump_0"+offset;
        System.out.println(path);
//        String path = "f:/code/OSClass/Receive/dump"+offset;
        int i = 0;
        int byteread;


        try{
            fos = new FileOutputStream(path);
            bos = new BufferedOutputStream(fos);
            int end = ((offset+1)*part_size)-1;
            URL url = new URL(this._url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Range","Bytes="+current+"-"+end);
            conn.connect();
            is = conn.getInputStream();
            byte[] byteArr = new byte[part_size];
            byteread = is.read(byteArr,0,byteArr.length);
            i = byteread;
            do{
                byteread = is.read(byteArr,i,byteArr.length-i);
                if(byteread>=0){
                    i += byteread;
                    jProgressBar.setValue(i);
                    percent = i/part_size*100;
//                    progress.setText(String.valueOf(percent)+"%");
                }
                System.out.println(offset+" "+i);
            }while (i<part_size);

            bos.write(byteArr,0,i);
            bos.flush();
            fos.close();
            bos.close();
            is.close();
        }
        catch (Exception e){

        }
    }




    public Progressbar_Thread(String url, JProgressBar jProgressBar,JLabel progress, int offset, int part_size,String directory){
        this.part_size = part_size;
        this.offset = offset;
        this._url = url;
        this.progress = progress;
        this.dir = directory;
        this.jProgressBar = jProgressBar;
        jProgressBar.setMaximum(part_size);
        jProgressBar.setMinimum(0);
    }
}


