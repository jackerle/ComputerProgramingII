import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.channels.ReadableByteChannel;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class Client_Downloader{
    private String f_name;
    private int f_size;
    private JPanel main_panel;
    private JPanel url_panel;
    private JLabel url_label;
    private JTextField url_textfield;
    private JButton url_button;
    private JLabel content_url_value;
    private JPanel content_directory;
    private JLabel content_directory_text;
    private JLabel content_directory_value;
    private JButton content_directory_change;
    private JPanel content_download;
    private JLabel content_download_text;
    private JLabel content_download_name;
    private JPanel content_download_size;
    private JLabel content_download_size_text;
    private JLabel content_download_size_value;
    private JButton download_button;
    private JPanel content_download_button;
    private JLabel progress_bar_text1;
    private JPanel content_progress_bar1;
    private JProgressBar progressBar1;
    private JLabel progress1;
    private JPanel content_progress_bar2;
    private JLabel progress_bar_text2;
    private JProgressBar progressBar2;
    private JLabel progress2;
    private JPanel content_progress_bar3;
    private JPanel content_progress_bar4;
    private JPanel content_progress_bar5;
    private JPanel content_progress_bar6;
    private JPanel content_progress_bar7;
    private JPanel content_progress_bar8;
    private JPanel content_progress_bar9;
    private JPanel content_progress_bar10;
    private JPanel content_text_total;
    private JPanel content_progress_bar_total;
    private JProgressBar progressBar3;
    private JProgressBar progressBar4;
    private JLabel progress3;
    private JLabel progress4;
    private JProgressBar progressBar5;
    private JLabel progress5;
    private JProgressBar progressBar6;
    private JLabel progress6;
    private JProgressBar progressBar7;
    private JLabel progress7;
    private JProgressBar progressBar8;
    private JLabel progress8;
    private JProgressBar progressBar9;
    private JLabel progress9;
    private JProgressBar progressBar10;
    private JLabel progress10;
    private JProgressBar progressBarTotal;
    private JLabel progressTotal;
    private JFileChooser f = new JFileChooser();
    private Downloader d = new Downloader();
    private String url;
    private String directory;


    public void set_directory_value (String directory){
        this.directory = directory;
        content_directory_value.setText(this.directory);
    }



    private void enter_url_handle(){
        url = url_textfield.getText();
        content_download_text.setText("FileName:");
        try {
            this.f_name = d.get_file_name(url);
            content_download_name.setText(this.f_name);
            if(d.can_download(url)){
                this.f_size = d.get_file_size(url);
                content_download_size_value.setText(String.valueOf(f_size)+" bytes");
                if(f_size!=-1)
                    download_button.setVisible(true);
                else
                    download_button.setVisible(false);
            }
            url_textfield.setText("");
        }
        catch (Exception e){

        }

    }

    private void download_handle(int size) throws Exception{
        ExecutorService pool = Executors.newFixedThreadPool(10);
        int part_size = size/10;
        pool.submit(new Progressbar_Thread(url,progressBar1,progress1,0,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar2,progress2,1,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar3,progress3,2,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar4,progress4,3,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar5,progress5,4,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar6,progress6,5,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar7,progress7,6,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar8,progress8,7,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar9,progress9,8,part_size,directory));
        pool.submit(new Progressbar_Thread(url,progressBar10,progress10,9,part_size,directory));
        pool.shutdown();
        while(!pool.isTerminated()){

        }
        System.out.println("success");
        Thread t1 = new Progress_Total_Thread(progressBarTotal,directory,size,this.f_name);
        t1.start();


    }

    public Client_Downloader() {
        download_button.setVisible(false);
        /*
            do when change url
         */
        url_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                enter_url_handle();
            }
        });



        content_directory_change.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                f.showSaveDialog(null);
                set_directory_value(f.getSelectedFile().toString());
            }
        });


        url_textfield.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                enter_url_handle();
            }
        });




        download_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try{
                    download_handle(f_size);
                }
                catch(Exception e){

                }

            }
        });
    }

    public static void main(String[] args) throws Exception{
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        Client_Downloader c = new Client_Downloader();
        JFrame frame = new JFrame("Client_Downloader");
        frame.setContentPane(c.main_panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setSize(800,400);
        frame.setVisible(true);
        frame.pack();
        //select file
        c.f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        c.f.showSaveDialog(null);
        c.set_directory_value(c.f.getSelectedFile().toString().replace("\\","/"));

    }
}
